

public class Ribbons  extends TreeDecorator
{
	Tree tree;
	public Ribbons(Tree t)
	{
		super(t);
		tree= t;
		cost = 2;
	}
	
	public String getName()
	{
		return tree.getName() + ", Ribbons";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
