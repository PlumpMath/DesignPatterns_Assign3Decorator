

public class LED  extends TreeDecorator
{
	Tree tree;
	public LED(Tree t)
	{
		super(t);
		tree= t;
		cost = 10;
	}
	
	public String getName()
	{
		return tree.getName() + ", LEDs";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
