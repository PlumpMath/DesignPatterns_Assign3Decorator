
public abstract class TreeDecorator extends Tree
{
	public abstract String getName();
	public TreeDecorator(Tree t)
	{
		hasStar = t.hasStar;
	}

}
