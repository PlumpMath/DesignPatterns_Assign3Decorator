

public class BalsamFir extends Tree
{
	public BalsamFir()
	{
		name = "Balsamic Fir";
		cost = 5;
	}
	
	public int cost()
	{
		
		return cost;
	}

}
