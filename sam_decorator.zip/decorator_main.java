public class decorator_main 
{
	public static void main(String [] args)
	{
		Tree mytree = new BlueSpruce();
		mytree = new Star(mytree);		
		mytree = new Ruffles(mytree);
		mytree = new Star(mytree); //this is problematic!
		mytree = new BallsBlue(mytree);
		mytree = new BallsRed(mytree);
		mytree = new BallsSilver(mytree);
		mytree = new LED(mytree);
		mytree = new Lights(mytree);
		mytree = new Ribbons(mytree);
		
		
		System.out.println(mytree.getName() + ". costs: " + mytree.cost() );
		
		
	}
	
}
