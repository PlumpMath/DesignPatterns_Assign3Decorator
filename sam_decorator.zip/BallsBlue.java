

public class BallsBlue extends TreeDecorator
{
	Tree tree;
	public BallsBlue(Tree t)
	{
		super(t);
		tree= t;
		cost = 2;
	}
	
	public String getName()
	{
		return tree.getName() + ", Balls Blue";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
