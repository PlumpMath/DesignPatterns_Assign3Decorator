

public class Ruffles  extends TreeDecorator
{
	Tree tree;
	public Ruffles(Tree t)
	{
		super(t);
		tree= t;
		cost = 1;
	}
	
	public String getName()
	{
		return tree.getName() + ", Ruffles";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
