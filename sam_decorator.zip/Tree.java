

public abstract class Tree 
{
	String name = "Tree";
	int cost = 0;//has to be set
	boolean hasStar = false;
		
	public String getName() 
	{
		return name + " is decorated with";
	}
	
	public abstract int cost();	

}
