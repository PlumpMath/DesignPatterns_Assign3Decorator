

public class DouglasFir extends Tree
{
	public DouglasFir()
	{
		name = "Douglas Fir";
		cost = 15;
	}
	
	public int cost()
	{
		
		return cost;
	}

}
