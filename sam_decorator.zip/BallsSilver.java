

public class BallsSilver extends TreeDecorator
{
	Tree tree;
	public BallsSilver(Tree t)
	{
		super(t);
		tree= t;
		cost = 3;
	}
	
	public String getName()
	{
		return tree.getName() + ", Balls Silver";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
