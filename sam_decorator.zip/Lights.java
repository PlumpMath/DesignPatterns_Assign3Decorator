

public class Lights  extends TreeDecorator
{
	Tree tree;
	public Lights(Tree t)
	{
		super(t);
		tree= t;
		cost = 5;
	}
	
	public String getName()
	{
		return tree.getName() + ", Lights";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
