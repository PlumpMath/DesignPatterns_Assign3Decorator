

public class BlueSpruce extends Tree
{
	public BlueSpruce()
	{
		name = "Blue Spruce";
		cost = 20;
	}
	
	public int cost()
	{
		
		return cost;
	}

}
