

public class FraserFir extends Tree
{
	public FraserFir()
	{
		name = "Fraser Fir";
		cost = 12;
	}
	
	public int cost()
	{
		
		return cost;
	}

}
