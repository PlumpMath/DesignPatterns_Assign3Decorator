

public class Star extends TreeDecorator
{
	Tree tree;
	public Star(Tree t)
	{
		super(t);
		if(t.hasStar)
		{
			System.out.println("Tree already has a star!");
			cost = 0;
			name = "";
			
		}
		else
		{
			cost = 4;
			name = ", a Star";
		}
			
		tree = t;
		this.hasStar = true;	
		
	}
	
	public String getName()
	{
		return tree.getName() + name;
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
