

public class BallsRed  extends TreeDecorator
{
	Tree tree;
	public BallsRed(Tree t)
	{
		super(t);
		tree= t;
		cost = 1;
	}
	
	public String getName()
	{
		return tree.getName() + ", Balls Red";
	}
	
	public int cost()
	{
		return cost + tree.cost();
	}

}
